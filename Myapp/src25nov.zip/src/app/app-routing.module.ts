import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { ClientComponent } from './client/client.component';
import { EmployeeComponent } from './employee/employee.component';
import { LocationComponent } from './location/location.component';
import { SitesComponent } from './sites/sites.component';
import { ClientAddComponent } from './client-add/client-add.component';


const routes: Routes = [
  { path:'',pathMatch:'full',redirectTo:'Dashboard'},
  { path:'Dashboard', component:DashboardComponent},
  { path:'Navbar', component:NavbarComponent},
  { path:'Sidebar', component:SidebarComponent},
  { path:'Client', component:ClientComponent},
  { path:'Employee', component:EmployeeComponent},
  { path:'Location', component:LocationComponent},
  { path:'Sites', component:SitesComponent},
  { path:'ClientAdd', component:ClientAddComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
